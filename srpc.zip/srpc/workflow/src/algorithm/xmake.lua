target("algorithm")
    set_kind("object")
    add_files("**.cc")